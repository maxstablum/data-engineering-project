# Assignment 1
In this Assignment, the python environment is organized by Conda and can be set up as followed:

1. Install Conda
2. Execute the following command ``conda env create -f env_ms.yml``
3. Execute the following command ``conda activate data-engineering``

Now the environment should be ready to execute the Jupyter Notebook

The tasks were done with a dataset from Kaggle. It contains 700 samples of user data, including metrics such as app usage time, screen-on time, battery drain, and data consumption.

